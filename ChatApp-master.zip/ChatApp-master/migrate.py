#!venv/bin/python

from chat import manager

if __name__ == '__main__':
    manager.run()
